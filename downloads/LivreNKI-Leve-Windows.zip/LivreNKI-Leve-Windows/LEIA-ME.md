# LivreNKI nativo para Windows

O LivreNKI é um catálogo leve para pastas de instrumentos `.nki`. Ele encontra os
timbres recursivamente, organiza as bibliotecas na lateral, pesquisa por nome ou
pasta e abre o arquivo escolhido no aplicativo associado pelo Windows.

## Uso

1. Extraia todo o ZIP e dê duplo clique em `Iniciar-LivreNKI.bat`. Você também
   pode executar `LivreNKI-Leve.exe` diretamente no Windows 10 ou 11.
2. Clique em **+ Adicionar pasta** e escolha a raiz de uma biblioteca.
3. Use a busca para localizar um timbre.
4. Dê duplo clique no timbre, pressione **Enter** ou clique em **Abrir no
   Kontakt**.

O Kontakt precisa estar instalado e associado à extensão `.nki` no Windows. O
LivreNKI não inclui samples, bibliotecas nem o Kontakt e não altera o conteúdo
dos arquivos. **Remover** tira a pasta somente do catálogo; nenhum arquivo é
apagado.

As raízes escolhidas são persistidas em:

```text
%APPDATA%\LivreNKI\settings.json
```

## Recursos

- interface Windows nativa, sem Electron ou servidor local;
- scan recursivo e extensão `.nki` sem diferença entre maiúsculas/minúsculas;
- várias bibliotecas, busca instantânea e atualização manual;
- scan em segundo plano para manter a janela responsiva;
- abertura pela associação oficial do Windows (`ShellExecuteW`);
- manifest Common Controls 6, DPI por monitor e suporte a caminhos longos;
- tema grafite com identidade própria do LivreNKI.

## Compilar

Requer Go 1.26 ou mais recente. O arquivo `rsrc_windows_amd64.syso` já contém o
manifest e o ícone; portanto, uma compilação normal não precisa do gerador de
recursos.

```powershell
$env:CGO_ENABLED = "0"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
go test ./...
go build -buildvcs=false -trimpath -ldflags "-H windowsgui -s -w" -o dist\LivreNKI-Leve.exe .
```

Para recriar o recurso depois de mudar `app.manifest` ou `icon.ico`:

```powershell
go install github.com/akavel/rsrc@v0.10.2
rsrc -manifest app.manifest -ico icon.ico -o rsrc_windows_amd64.syso
```

A interface usa [`github.com/lxn/walk`](https://github.com/lxn/walk), biblioteca
GUI pura Go para Win32. O build usa `CGO_ENABLED=0`.
