//go:build windows

package main

import (
	"fmt"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
)

const appTitle = "LivreNKI"

var (
	darkBackground = walk.RGB(24, 26, 30)
	darkPanel      = walk.RGB(31, 34, 39)
	darkInput      = walk.RGB(42, 45, 51)
	lightText      = walk.RGB(239, 241, 244)
	mutedText      = walk.RGB(171, 177, 186)
	accent         = walk.RGB(235, 143, 61)
)

type libraryListModel struct {
	walk.ListModelBase
	items []Library
}

func (m *libraryListModel) ItemCount() int { return len(m.items) }

func (m *libraryListModel) Value(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	lib := m.items[index]
	if lib.ScanError != "" {
		return fmt.Sprintf("%s  •  indisponível", lib.Name)
	}
	return fmt.Sprintf("%s  •  %s", lib.Name, instrumentCount(len(lib.Instruments)))
}

func (m *libraryListModel) ID(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	return strings.ToLower(m.items[index].Root)
}

func (m *libraryListModel) setItems(items []Library) {
	m.items = items
	m.PublishItemsReset()
}

type instrumentTableModel struct {
	walk.TableModelBase
	items []Instrument
}

func (m *instrumentTableModel) RowCount() int { return len(m.items) }

func (m *instrumentTableModel) Value(row, column int) interface{} {
	if row < 0 || row >= len(m.items) {
		return ""
	}
	item := m.items[row]
	switch column {
	case 0:
		return item.Name
	case 1:
		return item.Folder
	case 2:
		if item.ModifiedAt.IsZero() {
			return ""
		}
		return item.ModifiedAt.Format("02/01/2006 15:04")
	default:
		return ""
	}
}

func (m *instrumentTableModel) ID(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	return strings.ToLower(m.items[index].Path)
}

func (m *instrumentTableModel) setItems(items []Instrument) {
	m.items = items
	m.PublishRowsReset()
}

type nativeApp struct {
	mw              *walk.MainWindow
	libraryList     *walk.ListBox
	instrumentTable *walk.TableView
	search          *walk.LineEdit
	libraryTitle    *walk.Label
	rootLabel       *walk.Label
	statusLabel     *walk.Label
	removeButton    *walk.PushButton
	refreshButton   *walk.PushButton
	openButton      *walk.PushButton

	libraryModel    *libraryListModel
	instrumentModel *instrumentTableModel
	libraries       []Library
	settingsPath    string
	scanRevision    uint64
}

func main() {
	if err := run(); err != nil {
		walk.MsgBox(nil, appTitle, err.Error(), walk.MsgBoxOK|walk.MsgBoxIconError)
	}
}

func run() error {
	settingsPath, err := defaultSettingsPath()
	if err != nil {
		return err
	}

	settings, loadErr := loadSettings(settingsPath)
	a := &nativeApp{
		libraryModel:    &libraryListModel{},
		instrumentModel: &instrumentTableModel{},
		settingsPath:    settingsPath,
	}
	for _, root := range settings.Roots {
		a.libraries = append(a.libraries, Library{Name: libraryName(root), Root: root})
	}
	a.libraryModel.items = a.libraries

	if err := a.createWindow(); err != nil {
		return fmt.Errorf("criar janela: %w", err)
	}
	setDarkTitleBar(uintptr(a.mw.Handle()))

	if loadErr != nil {
		a.setStatus("Não foi possível ler as configurações: " + loadErr.Error())
	} else if len(a.libraries) == 0 {
		a.setStatus("Adicione uma pasta para começar a catalogar seus timbres .nki.")
	} else {
		a.libraryList.SetCurrentIndex(0)
		a.updateSelectedLibrary()
		a.startScan()
	}

	a.mw.Run()
	return nil
}

func (a *nativeApp) createWindow() error {
	backgroundBrush := SolidColorBrush{Color: darkBackground}
	panelBrush := SolidColorBrush{Color: darkPanel}
	inputBrush := SolidColorBrush{Color: darkInput}

	return (MainWindow{
		AssignTo:   &a.mw,
		Title:      appTitle + " — Bibliotecas NKI",
		Size:       Size{Width: 1120, Height: 720},
		MinSize:    Size{Width: 840, Height: 520},
		Background: backgroundBrush,
		Font:       Font{Family: "Segoe UI", PointSize: 10},
		Layout:     VBox{MarginsZero: true, SpacingZero: true},
		Children: []Widget{
			Composite{
				MinSize:    Size{Height: 76},
				MaxSize:    Size{Height: 76},
				Background: panelBrush,
				Layout:     HBox{Margins: Margins{Left: 20, Top: 12, Right: 20, Bottom: 10}, Spacing: 12},
				Children: []Widget{
					Composite{
						Background: panelBrush,
						Layout:     VBox{MarginsZero: true, Spacing: 1},
						Children: []Widget{
							Label{Text: "LivreNKI", TextColor: accent, Font: Font{Family: "Segoe UI", PointSize: 19, Bold: true}},
							Label{Text: "Suas bibliotecas e timbres em um só lugar", TextColor: mutedText},
						},
					},
				},
			},
			HSplitter{
				HandleWidth: 5,
				Background:  backgroundBrush,
				Children: []Widget{
					Composite{
						MinSize:       Size{Width: 270},
						MaxSize:       Size{Width: 390},
						StretchFactor: 1,
						Background:    panelBrush,
						Layout:        VBox{Margins: Margins{Left: 14, Top: 15, Right: 14, Bottom: 14}, Spacing: 8},
						Children: []Widget{
							Label{Text: "BIBLIOTECAS", TextColor: mutedText, Font: Font{Family: "Segoe UI", PointSize: 9, Bold: true}},
							Composite{
								Background: panelBrush,
								Layout:     HBox{MarginsZero: true, Spacing: 6},
								Children: []Widget{
									PushButton{Text: "+ Adicionar pasta", StretchFactor: 2, OnClicked: a.addLibrary},
									PushButton{AssignTo: &a.removeButton, Text: "Remover", StretchFactor: 1, Enabled: false, OnClicked: a.removeLibrary},
								},
							},
							ListBox{
								AssignTo:              &a.libraryList,
								Model:                 a.libraryModel,
								OnCurrentIndexChanged: a.updateSelectedLibrary,
							},
							Label{AssignTo: &a.rootLabel, Text: "Nenhuma pasta adicionada", TextColor: mutedText, EllipsisMode: EllipsisPath},
						},
					},
					Composite{
						StretchFactor: 3,
						Background:    backgroundBrush,
						Layout:        VBox{Margins: Margins{Left: 16, Top: 15, Right: 16, Bottom: 12}, Spacing: 9},
						Children: []Widget{
							Label{AssignTo: &a.libraryTitle, Text: "Timbres", TextColor: lightText, Font: Font{Family: "Segoe UI", PointSize: 15, Bold: true}},
							Composite{
								Background: backgroundBrush,
								Layout:     HBox{MarginsZero: true, Spacing: 7},
								Children: []Widget{
									LineEdit{
										AssignTo:      &a.search,
										StretchFactor: 3,
										CueBanner:     "Buscar por nome ou pasta...",
										Background:    inputBrush,
										TextColor:     lightText,
										OnTextChanged: a.applyFilter,
									},
									PushButton{AssignTo: &a.refreshButton, Text: "Atualizar", OnClicked: a.startScan},
									PushButton{AssignTo: &a.openButton, Text: "Abrir no Kontakt", Enabled: false, OnClicked: a.openSelected},
								},
							},
							TableView{
								AssignTo:            &a.instrumentTable,
								Model:               a.instrumentModel,
								AlternatingRowBG:    true,
								ColumnsSizable:      true,
								LastColumnStretched: false,
								Columns: []TableViewColumn{
									{Title: "Timbre", Width: 310},
									{Title: "Pasta", Width: 430},
									{Title: "Modificado", Width: 135},
								},
								OnItemActivated:       a.openSelected,
								OnCurrentIndexChanged: a.updateOpenButton,
							},
							Label{AssignTo: &a.statusLabel, Text: "Pronto", TextColor: mutedText},
						},
					},
				},
			},
		},
	}).Create()
}

func (a *nativeApp) addLibrary() {
	dialog := new(walk.FileDialog)
	dialog.Title = "Adicionar pasta de biblioteca NKI"
	accepted, err := dialog.ShowBrowseFolder(a.mw)
	if err != nil {
		a.showError("Não foi possível abrir a pasta", err)
		return
	}
	if !accepted || strings.TrimSpace(dialog.FilePath) == "" {
		return
	}

	root := filepath.Clean(dialog.FilePath)
	for index, lib := range a.libraries {
		if strings.EqualFold(lib.Root, root) {
			a.libraryList.SetCurrentIndex(index)
			a.setStatus("Esta biblioteca já está na lista.")
			return
		}
	}

	a.libraries = append(a.libraries, Library{Name: libraryName(root), Root: root})
	a.libraryModel.setItems(a.libraries)
	a.libraryList.SetCurrentIndex(len(a.libraries) - 1)
	a.updateSelectedLibrary()
	if err := a.persistRoots(); err != nil {
		a.showError("A biblioteca foi adicionada, mas não pôde ser salva", err)
	}
	a.startScan()
}

func (a *nativeApp) removeLibrary() {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		return
	}
	removedName := a.libraries[index].Name
	a.libraries = append(a.libraries[:index], a.libraries[index+1:]...)
	a.libraryModel.setItems(a.libraries)
	if len(a.libraries) > 0 {
		if index >= len(a.libraries) {
			index = len(a.libraries) - 1
		}
		a.libraryList.SetCurrentIndex(index)
	} else {
		a.libraryList.SetCurrentIndex(-1)
	}
	a.updateSelectedLibrary()
	if err := a.persistRoots(); err != nil {
		a.showError("Não foi possível salvar a remoção", err)
		return
	}
	a.scanRevision++ // Invalidate a scan that may still be running.
	a.refreshButton.SetEnabled(len(a.libraries) > 0)
	a.setStatus(fmt.Sprintf("%s foi removida da lista. Nenhum arquivo foi apagado.", removedName))
}

func (a *nativeApp) persistRoots() error {
	roots := make([]string, len(a.libraries))
	for index, lib := range a.libraries {
		roots[index] = lib.Root
	}
	return saveSettings(a.settingsPath, Settings{Roots: roots})
}

func (a *nativeApp) startScan() {
	if len(a.libraries) == 0 {
		a.setStatus("Adicione uma pasta para começar.")
		return
	}

	selectedRoot := a.currentRoot()
	roots := make([]string, len(a.libraries))
	for index, lib := range a.libraries {
		roots[index] = lib.Root
	}
	a.scanRevision++
	revision := a.scanRevision
	a.refreshButton.SetEnabled(false)
	a.setStatus(fmt.Sprintf("Escaneando %d biblioteca(s)...", len(roots)))

	go func() {
		scanned := make([]Library, 0, len(roots))
		for _, root := range roots {
			scanned = append(scanned, scanLibrary(root))
		}
		a.mw.Synchronize(func() {
			if revision != a.scanRevision {
				return
			}
			a.libraries = scanned
			a.libraryModel.setItems(a.libraries)
			index := a.indexOfRoot(selectedRoot)
			if index < 0 && len(a.libraries) > 0 {
				index = 0
			}
			a.libraryList.SetCurrentIndex(index)
			a.refreshButton.SetEnabled(true)
			a.updateSelectedLibrary()

			total, failures := 0, 0
			for _, lib := range a.libraries {
				total += len(lib.Instruments)
				if lib.ScanError != "" {
					failures++
				}
			}
			if failures > 0 {
				a.setStatus(fmt.Sprintf("%s encontrados. %d biblioteca(s) não puderam ser lidas.", instrumentCount(total), failures))
			} else {
				a.setStatus(fmt.Sprintf("%s encontrados em %d biblioteca(s).", instrumentCount(total), len(a.libraries)))
			}
		})
	}()
}

func (a *nativeApp) currentRoot() string {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		return ""
	}
	return a.libraries[index].Root
}

func (a *nativeApp) indexOfRoot(root string) int {
	for index, lib := range a.libraries {
		if strings.EqualFold(lib.Root, root) {
			return index
		}
	}
	return -1
}

func (a *nativeApp) updateSelectedLibrary() {
	index := a.libraryList.CurrentIndex()
	valid := index >= 0 && index < len(a.libraries)
	a.removeButton.SetEnabled(valid)
	if !valid {
		a.libraryTitle.SetText("Timbres")
		a.rootLabel.SetText("Nenhuma pasta adicionada")
		a.instrumentModel.setItems(nil)
		a.openButton.SetEnabled(false)
		return
	}

	lib := a.libraries[index]
	a.libraryTitle.SetText(fmt.Sprintf("%s  ·  %s", lib.Name, instrumentCount(len(lib.Instruments))))
	a.rootLabel.SetText(lib.Root)
	a.rootLabel.SetToolTipText(lib.Root)
	a.applyFilter()
	if lib.ScanError != "" {
		a.setStatus(lib.ScanError)
	}
}

func (a *nativeApp) applyFilter() {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		a.instrumentModel.setItems(nil)
		a.openButton.SetEnabled(false)
		return
	}
	filtered := filterInstruments(a.libraries[index].Instruments, a.search.Text())
	a.instrumentModel.setItems(filtered)
	a.openButton.SetEnabled(len(filtered) > 0)
	query := strings.TrimSpace(a.search.Text())
	if query != "" {
		a.setStatus(fmt.Sprintf("%s correspondem à busca “%s”.", instrumentCount(len(filtered)), query))
	}
}

func (a *nativeApp) updateOpenButton() {
	index := a.instrumentTable.CurrentIndex()
	a.openButton.SetEnabled(index >= 0 && index < len(a.instrumentModel.items))
}

func (a *nativeApp) openSelected() {
	index := a.instrumentTable.CurrentIndex()
	if index < 0 || index >= len(a.instrumentModel.items) {
		return
	}
	item := a.instrumentModel.items[index]
	if err := shellOpen(uintptr(a.mw.Handle()), item.Path); err != nil {
		a.showError("Não foi possível abrir o timbre", err)
		return
	}
	a.setStatus("Abrindo “" + item.Name + "” no aplicativo associado a .nki...")
}

func (a *nativeApp) setStatus(message string) {
	if a.statusLabel != nil {
		a.statusLabel.SetText(message)
	}
}

func (a *nativeApp) showError(title string, err error) {
	walk.MsgBox(a.mw, title, err.Error(), walk.MsgBoxOK|walk.MsgBoxIconError)
}

func instrumentCount(count int) string {
	if count == 1 {
		return "1 timbre"
	}
	return fmt.Sprintf("%d timbres", count)
}

var shellExecuteW = syscall.NewLazyDLL("shell32.dll").NewProc("ShellExecuteW")

func shellOpen(hwnd uintptr, path string) error {
	verb, err := syscall.UTF16PtrFromString("open")
	if err != nil {
		return err
	}
	file, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return err
	}
	result, _, callErr := shellExecuteW.Call(
		hwnd,
		uintptr(unsafe.Pointer(verb)),
		uintptr(unsafe.Pointer(file)),
		0,
		0,
		1, // SW_SHOWNORMAL
	)
	if result > 32 {
		return nil
	}
	if result == 31 {
		return fmt.Errorf("nenhum aplicativo está associado a arquivos .nki; associe a extensão .nki ao Kontakt no Windows")
	}
	if result == 2 || result == 3 {
		return fmt.Errorf("o arquivo não existe mais: %s", path)
	}
	if callErr != nil && callErr != syscall.Errno(0) {
		return fmt.Errorf("abrir arquivo: %w", callErr)
	}
	return fmt.Errorf("o Windows não conseguiu abrir o arquivo (código %d)", result)
}

func setDarkTitleBar(hwnd uintptr) {
	value := int32(1)
	proc := syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
	// DWMWA_USE_IMMERSIVE_DARK_MODE is 20 on current Windows 10/11 and 19 on
	// some older builds. Unsupported calls simply leave the native title bar.
	for _, attribute := range []uintptr{20, 19} {
		result, _, _ := proc.Call(hwnd, attribute, uintptr(unsafe.Pointer(&value)), unsafe.Sizeof(value))
		if result == 0 {
			return
		}
	}
}
