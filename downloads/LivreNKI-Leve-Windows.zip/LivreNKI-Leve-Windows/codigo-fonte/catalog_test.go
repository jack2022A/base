package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestScanNKIRecursiveAndCaseInsensitive(t *testing.T) {
	root := t.TempDir()
	mustWrite := func(relative string) {
		t.Helper()
		path := filepath.Join(root, relative)
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte("fixture"), 0o644); err != nil {
			t.Fatal(err)
		}
	}

	mustWrite("Pianos/Grand Piano.nki")
	mustWrite("Synths/LEAD.NKI")
	mustWrite("Synths/readme.txt")
	mustWrite("node_modules/ignored.nki")
	mustWrite(".git/also-ignored.nki")

	items, err := scanNKI(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 2 {
		t.Fatalf("esperava 2 timbres, recebeu %d: %#v", len(items), items)
	}
	if items[0].Name != "Grand Piano" || items[0].Folder != "Pianos" {
		t.Fatalf("primeiro timbre inesperado: %#v", items[0])
	}
	if items[1].Name != "LEAD" || items[1].Folder != "Synths" {
		t.Fatalf("segundo timbre inesperado: %#v", items[1])
	}
}

func TestSettingsRoundTripAndReplace(t *testing.T) {
	path := filepath.Join(t.TempDir(), "LivreNKI", "settings.json")
	first := filepath.Join(t.TempDir(), "Library One")
	second := filepath.Join(t.TempDir(), "Library Two")

	if err := saveSettings(path, Settings{Roots: []string{first, first, ""}}); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSettings(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Roots) != 1 || loaded.Roots[0] != filepath.Clean(first) {
		t.Fatalf("raízes inesperadas após primeira gravação: %#v", loaded.Roots)
	}

	if err := saveSettings(path, Settings{Roots: []string{second}}); err != nil {
		t.Fatal(err)
	}
	loaded, err = loadSettings(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Roots) != 1 || loaded.Roots[0] != filepath.Clean(second) {
		t.Fatalf("arquivo não foi substituído: %#v", loaded.Roots)
	}
}

func TestFilterInstrumentsMatchesNameFolderAndPath(t *testing.T) {
	items := []Instrument{
		{Name: "Grand Piano", Folder: "Acoustic", Path: filepath.Join("C:", "Samples", "Piano.nki")},
		{Name: "Warm Pad", Folder: "Synth Leads", Path: filepath.Join("D:", "Pads", "Warm.nki")},
	}

	for query, expected := range map[string]string{
		"piano":    "Grand Piano",
		"acoustic": "Grand Piano",
		"pads":     "Warm Pad",
		"  WARM  ": "Warm Pad",
	} {
		filtered := filterInstruments(items, query)
		if len(filtered) != 1 || filtered[0].Name != expected {
			t.Errorf("busca %q: resultado %#v, esperava %q", query, filtered, expected)
		}
	}

	if filtered := filterInstruments(items, "não existe"); len(filtered) != 0 {
		t.Fatalf("busca sem resultado retornou %#v", filtered)
	}
}

func TestScanLibraryReportsMissingRoot(t *testing.T) {
	missing := filepath.Join(t.TempDir(), "missing")
	lib := scanLibrary(missing)
	if lib.ScanError == "" {
		t.Fatal("esperava erro para uma biblioteca ausente")
	}
	if lib.Name != "missing" {
		t.Fatalf("nome inesperado: %q", lib.Name)
	}
}
