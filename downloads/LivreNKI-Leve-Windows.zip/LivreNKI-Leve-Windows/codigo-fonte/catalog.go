package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// Settings contains only the folders selected by the user.  Instrument data is
// rebuilt from disk so the catalog never gets stale when files are moved.
type Settings struct {
	Roots []string `json:"roots"`
}

type Instrument struct {
	Name       string
	Path       string
	Folder     string
	ModifiedAt time.Time
}

type Library struct {
	Name        string
	Root        string
	Instruments []Instrument
	ScanError   string
}

func defaultSettingsPath() (string, error) {
	// On Windows, APPDATA is the roaming application-data folder requested by
	// the application contract. UserConfigDir is a safe fallback for unusual
	// environments where APPDATA is not defined.
	base := strings.TrimSpace(os.Getenv("APPDATA"))
	if base == "" {
		var err error
		base, err = os.UserConfigDir()
		if err != nil {
			return "", fmt.Errorf("localizar pasta de configurações: %w", err)
		}
	}
	return filepath.Join(base, "LivreNKI", "settings.json"), nil
}

func loadSettings(path string) (Settings, error) {
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return Settings{}, nil
	}
	if err != nil {
		return Settings{}, fmt.Errorf("ler configurações: %w", err)
	}

	var settings Settings
	if err := json.Unmarshal(data, &settings); err != nil {
		return Settings{}, fmt.Errorf("configurações inválidas: %w", err)
	}
	settings.Roots = uniqueRoots(settings.Roots)
	return settings, nil
}

func saveSettings(path string, settings Settings) error {
	settings.Roots = uniqueRoots(settings.Roots)
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return fmt.Errorf("criar pasta de configurações: %w", err)
	}

	tmp, err := os.CreateTemp(dir, "settings-*.tmp")
	if err != nil {
		return fmt.Errorf("criar configuração temporária: %w", err)
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)

	encoder := json.NewEncoder(tmp)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(settings); err != nil {
		tmp.Close()
		return fmt.Errorf("gravar configurações: %w", err)
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return fmt.Errorf("sincronizar configurações: %w", err)
	}
	if err := tmp.Close(); err != nil {
		return fmt.Errorf("fechar configurações: %w", err)
	}

	if err := os.Rename(tmpName, path); err != nil {
		// Replacing an existing file can fail on some Windows versions. Remove
		// the old settings file and immediately retry the completed temp file.
		if removeErr := os.Remove(path); removeErr != nil && !errors.Is(removeErr, os.ErrNotExist) {
			return fmt.Errorf("substituir configurações: %w", err)
		}
		if retryErr := os.Rename(tmpName, path); retryErr != nil {
			return fmt.Errorf("substituir configurações: %w", retryErr)
		}
	}
	return nil
}

func uniqueRoots(roots []string) []string {
	result := make([]string, 0, len(roots))
	seen := make(map[string]struct{}, len(roots))
	for _, root := range roots {
		root = strings.TrimSpace(root)
		if root == "" {
			continue
		}
		if abs, err := filepath.Abs(root); err == nil {
			root = abs
		}
		root = filepath.Clean(root)
		key := strings.ToLower(root) // LivreNKI runs on case-insensitive Windows.
		if _, exists := seen[key]; exists {
			continue
		}
		seen[key] = struct{}{}
		result = append(result, root)
	}
	return result
}

func libraryName(root string) string {
	clean := filepath.Clean(root)
	name := filepath.Base(clean)
	if name == "." || name == string(filepath.Separator) || name == "" {
		name = filepath.VolumeName(clean)
	}
	if name == "" {
		return clean
	}
	return name
}

func scanLibrary(root string) Library {
	lib := Library{Name: libraryName(root), Root: root}
	items, err := scanNKI(root)
	if err != nil {
		lib.ScanError = err.Error()
	}
	lib.Instruments = items
	return lib
}

func scanNKI(root string) ([]Instrument, error) {
	info, err := os.Stat(root)
	if err != nil {
		return nil, fmt.Errorf("abrir %s: %w", root, err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("%s não é uma pasta", root)
	}

	var items []Instrument
	err = filepath.WalkDir(root, func(path string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			// A protected subfolder should not hide the instruments in every
			// other folder. A failure at the selected root is still reported.
			if filepath.Clean(path) == filepath.Clean(root) {
				return walkErr
			}
			if entry != nil && entry.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		if entry.IsDir() {
			if path != root && shouldSkipDirectory(entry.Name()) {
				return filepath.SkipDir
			}
			return nil
		}
		if !strings.EqualFold(filepath.Ext(entry.Name()), ".nki") {
			return nil
		}

		folder := "."
		if rel, relErr := filepath.Rel(root, filepath.Dir(path)); relErr == nil {
			folder = rel
		}
		if folder == "." {
			folder = "Raiz da biblioteca"
		}

		instrument := Instrument{
			Name:   strings.TrimSuffix(entry.Name(), filepath.Ext(entry.Name())),
			Path:   path,
			Folder: folder,
		}
		if fileInfo, infoErr := entry.Info(); infoErr == nil {
			instrument.ModifiedAt = fileInfo.ModTime()
		}
		items = append(items, instrument)
		return nil
	})
	if err != nil {
		return items, fmt.Errorf("escanear %s: %w", root, err)
	}

	sort.Slice(items, func(i, j int) bool {
		left := strings.ToLower(items[i].Name)
		right := strings.ToLower(items[j].Name)
		if left == right {
			return strings.ToLower(items[i].Path) < strings.ToLower(items[j].Path)
		}
		return left < right
	})
	return items, nil
}

func shouldSkipDirectory(name string) bool {
	switch strings.ToLower(name) {
	case "$recycle.bin", "system volume information", ".git", "node_modules":
		return true
	default:
		return false
	}
}

func filterInstruments(items []Instrument, query string) []Instrument {
	query = strings.ToLower(strings.TrimSpace(query))
	if query == "" {
		return append([]Instrument(nil), items...)
	}
	filtered := make([]Instrument, 0, len(items))
	for _, item := range items {
		haystack := strings.ToLower(item.Name + "\n" + item.Folder + "\n" + item.Path)
		if strings.Contains(haystack, query) {
			filtered = append(filtered, item)
		}
	}
	return filtered
}
