# LivreNKI Universal para Windows

O LivreNKI é um catálogo leve para arquivos relacionados ao Kontakt. Ele separa
o conteúdo em **Carregáveis**, **Presets**, **Componentes** e **Suporte**,
organiza as bibliotecas na lateral e pesquisa recursivamente por nome, pasta,
tipo ou extensão.

## Uso

1. Extraia todo o ZIP e dê duplo clique em `Iniciar-LivreNKI.bat`. Você também
   pode executar `LivreNKI-Universal.exe` diretamente no Windows 10 ou 11.
2. Clique em **Selecionar Kontakt.exe** e escolha o executável da sua instalação.
   Essa etapa é opcional; sem ela, o LivreNKI usa a associação do Windows.
3. Clique em **+ Adicionar pasta** e escolha a raiz de uma biblioteca.
4. Use a busca e o seletor de categoria para localizar um arquivo.
5. Para `.nki`, `.nkm` e `.nkb`, dê duplo clique ou use **Abrir no Kontakt**.
   Para os demais tipos, use **Mostrar na pasta**.

O Kontakt precisa estar instalado. Quando um `Kontakt.exe` é selecionado, o
LivreNKI inicia esse executável e passa o arquivo escolhido como argumento, sem
usar o prompt de comandos. Sem um executável configurado, as extensões precisam
estar associadas ao Kontakt no Windows. Snapshots `.nksn` e presets `.nksf`
dependem do instrumento ou produto correspondente. O LivreNKI os localiza e
mostra no Explorador de Arquivos, sem tentar abri-los como instrumentos.
O LivreNKI não inclui samples, bibliotecas nem o Kontakt e não altera o conteúdo
dos arquivos. **Remover** tira a pasta somente do catálogo; nenhum arquivo é apagado.

Componentes `.nka`, `.nkg` e `.nkp` e arquivos de suporte `.nicnt`, `.nkr`,
`.nkx`, `.nkc` e `.ncw` aparecem no catálogo para localização e diagnóstico.
Eles não são enviados ao Kontakt; a ação disponível apenas seleciona o arquivo
na sua pasta. Áudio genérico `.wav`, `.aif` e `.aiff` não é indexado para evitar
catálogos excessivamente grandes.

As raízes escolhidas e o caminho opcional do Kontakt são persistidos em:

```text
%APPDATA%\LivreNKI\settings.json
```

## Recursos

- interface Windows nativa, sem Electron ou servidor local;
- scan recursivo de arquivos carregáveis, presets, componentes e suporte, sem
  diferença entre maiúsculas/minúsculas;
- várias bibliotecas, busca instantânea, filtro por categoria e atualização manual;
- scan em segundo plano para manter a janela responsiva;
- abertura pela associação oficial do Windows (`ShellExecuteW`);
- seleção opcional do `Kontakt.exe`, com argumento de arquivo protegido e retorno
  para a associação do Windows pelo botão **Usar associação**;
- ação **Mostrar na pasta** para todo item que depende de contexto interno;
- manifest Common Controls 6, DPI por monitor e suporte a caminhos longos;
- tema grafite com identidade própria do LivreNKI.

## Compilar

Requer Go 1.26 ou mais recente. O arquivo `rsrc_windows_amd64.syso` já contém o
manifest e o ícone; portanto, uma compilação normal não precisa do gerador de
recursos.

```powershell
$env:CGO_ENABLED = "0"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
go test ./...
go build -buildvcs=false -trimpath -ldflags "-H windowsgui -s -w" -o dist\LivreNKI-Universal.exe .
```

Para recriar o recurso depois de mudar `app.manifest` ou `icon.ico`:

```powershell
go install github.com/akavel/rsrc@v0.10.2
rsrc -manifest app.manifest -ico icon.ico -o rsrc_windows_amd64.syso
```

A interface usa [`github.com/lxn/walk`](https://github.com/lxn/walk), biblioteca
GUI pura Go para Win32. O build usa `CGO_ENABLED=0`.
