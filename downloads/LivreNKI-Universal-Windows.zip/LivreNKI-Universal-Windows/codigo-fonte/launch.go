package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func normalizeKontaktPath(path string) string {
	path = strings.TrimSpace(path)
	if path == "" {
		return ""
	}
	if absolute, err := filepath.Abs(path); err == nil {
		path = absolute
	}
	return filepath.Clean(path)
}

func validateKontaktExecutable(path string) error {
	if strings.TrimSpace(path) == "" {
		return fmt.Errorf("selecione o arquivo executável do Kontakt")
	}
	if !strings.EqualFold(filepath.Ext(path), ".exe") {
		return fmt.Errorf("o arquivo selecionado não possui a extensão .exe")
	}
	info, err := os.Stat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return fmt.Errorf("o executável configurado não existe: %s", path)
		}
		return fmt.Errorf("verificar executável do Kontakt: %w", err)
	}
	if !info.Mode().IsRegular() {
		return fmt.Errorf("o caminho configurado não é um arquivo executável: %s", path)
	}
	return nil
}

// quoteWindowsArgument applies the CommandLineToArgvW quoting rules. Passing a
// parameter string separately to ShellExecuteW avoids invoking cmd.exe; this
// quoting only preserves spaces and backslashes in the document path.
func quoteWindowsArgument(argument string) string {
	if argument != "" && !strings.ContainsAny(argument, " \t\n\v\"") {
		return argument
	}
	return quoteWindowsArgumentAlways(argument)
}

func quoteWindowsArgumentAlways(argument string) string {
	var quoted strings.Builder
	quoted.WriteByte('"')
	backslashes := 0
	for _, character := range argument {
		if character == '\\' {
			backslashes++
			continue
		}
		if character == '"' {
			quoted.WriteString(strings.Repeat("\\", backslashes*2+1))
			quoted.WriteRune(character)
			backslashes = 0
			continue
		}
		quoted.WriteString(strings.Repeat("\\", backslashes))
		backslashes = 0
		quoted.WriteRune(character)
	}
	quoted.WriteString(strings.Repeat("\\", backslashes*2))
	quoted.WriteByte('"')
	return quoted.String()
}

func explorerSelectParameters(path string) string {
	return "/select," + quoteWindowsArgumentAlways(path)
}
