package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestScanKontaktFilesRecursiveAndCaseInsensitive(t *testing.T) {
	root := t.TempDir()
	mustWrite := func(relative string) {
		t.Helper()
		path := filepath.Join(root, relative)
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte("fixture"), 0o644); err != nil {
			t.Fatal(err)
		}
	}

	mustWrite("Pianos/Grand Piano.nki")
	mustWrite("Synths/LEAD.NKI")
	mustWrite("Multis/Stage Rig.nkm")
	mustWrite("Banks/Legacy Bank.NKB")
	mustWrite("Snapshots/Soft Pad.nksn")
	mustWrite("Presets/Hybrid Keys.nksf")
	mustWrite("Synths/readme.txt")
	mustWrite("Library/library.nicnt")
	mustWrite("Library/resources.nkx")
	mustWrite("Library/resources.nkc")
	mustWrite("Library/resources.nkr")
	mustWrite("Samples/sample.ncw")
	mustWrite("Scripts/data.nka")
	mustWrite("Groups/section.nkg")
	mustWrite("Presets/effect.nkp")
	mustWrite("Samples/raw.wav")
	mustWrite("Samples/raw.aiff")
	mustWrite("node_modules/ignored.nki")
	mustWrite(".git/also-ignored.nki")

	items, err := scanKontaktFiles(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 14 {
		t.Fatalf("esperava 14 arquivos relacionados ao Kontakt, recebeu %d: %#v", len(items), items)
	}

	want := map[string]kontaktFileSpec{
		".nki":   {Kind: "Instrumento", Category: KontaktCategoryLoadable, OpenMode: OpenModeKontakt},
		".nkm":   {Kind: "Multi", Category: KontaktCategoryLoadable, OpenMode: OpenModeKontakt},
		".nkb":   {Kind: "Banco", Category: KontaktCategoryLoadable, OpenMode: OpenModeKontakt},
		".nksn":  {Kind: "Snapshot", Category: KontaktCategoryPreset, OpenMode: OpenModeReveal},
		".nksf":  {Kind: "Preset NKS", Category: KontaktCategoryPreset, OpenMode: OpenModeReveal},
		".nkg":   {Kind: "Grupo", Category: KontaktCategoryComponent, OpenMode: OpenModeReveal},
		".nkp":   {Kind: "Preset de módulo", Category: KontaktCategoryComponent, OpenMode: OpenModeReveal},
		".nka":   {Kind: "Array de script", Category: KontaktCategoryComponent, OpenMode: OpenModeReveal},
		".nicnt": {Kind: "Descritor de biblioteca", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
		".nkr":   {Kind: "Recurso", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
		".nkx":   {Kind: "Contêiner", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
		".nkc":   {Kind: "Índice", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
		".ncw":   {Kind: "Sample comprimido", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
	}
	counts := make(map[string]int)
	for _, item := range items {
		spec, supported := want[item.Extension]
		if !supported {
			t.Fatalf("extensão inesperada entrou no catálogo: %#v", item)
		}
		if item.Kind != spec.Kind || item.Category != spec.Category || item.OpenMode != spec.OpenMode {
			t.Errorf("classificação de %s: recebeu %#v, esperava %#v", item.Path, item, spec)
		}
		counts[item.Extension]++
	}
	if counts[".nki"] != 2 || counts[".nkm"] != 1 || counts[".nkb"] != 1 || counts[".nksn"] != 1 {
		t.Fatalf("contagens inesperadas por extensão: %#v", counts)
	}
}

func TestSettingsRoundTripAndReplace(t *testing.T) {
	path := filepath.Join(t.TempDir(), "LivreNKI", "settings.json")
	first := filepath.Join(t.TempDir(), "Library One")
	second := filepath.Join(t.TempDir(), "Library Two")
	kontaktPath := filepath.Join(t.TempDir(), "Native Instruments", "Kontakt 8.exe")
	if err := os.MkdirAll(filepath.Dir(kontaktPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(kontaktPath, []byte("fixture"), 0o755); err != nil {
		t.Fatal(err)
	}

	if err := saveSettings(path, Settings{Roots: []string{first, first, ""}, KontaktPath: kontaktPath}); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSettings(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Roots) != 1 || loaded.Roots[0] != filepath.Clean(first) {
		t.Fatalf("raízes inesperadas após primeira gravação: %#v", loaded.Roots)
	}
	if loaded.KontaktPath != filepath.Clean(kontaktPath) {
		t.Fatalf("Kontakt inesperado após primeira gravação: %q", loaded.KontaktPath)
	}

	if err := saveSettings(path, Settings{Roots: []string{second}, KontaktPath: kontaktPath}); err != nil {
		t.Fatal(err)
	}
	loaded, err = loadSettings(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Roots) != 1 || loaded.Roots[0] != filepath.Clean(second) {
		t.Fatalf("arquivo não foi substituído: %#v", loaded.Roots)
	}
	if loaded.KontaktPath != filepath.Clean(kontaktPath) {
		t.Fatalf("Kontakt foi perdido ao substituir configurações: %q", loaded.KontaktPath)
	}
}

func TestLoadSettingsWithoutKontaktPathIsBackwardCompatible(t *testing.T) {
	path := filepath.Join(t.TempDir(), "settings.json")
	if err := os.WriteFile(path, []byte(`{"roots":["Library"]}`), 0o644); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadSettings(path)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.KontaktPath != "" {
		t.Fatalf("configuração antiga deveria usar associação do Windows: %q", loaded.KontaktPath)
	}
	if len(loaded.Roots) != 1 {
		t.Fatalf("raízes da configuração antiga foram perdidas: %#v", loaded.Roots)
	}
}

func TestFilterInstrumentsMatchesNameFolderAndPath(t *testing.T) {
	items := []Instrument{
		{Name: "Grand Piano", Folder: "Acoustic", Path: filepath.Join("C:", "Samples", "Piano.nki"), Kind: "Instrumento", Extension: ".nki", Category: KontaktCategoryLoadable, OpenMode: OpenModeKontakt},
		{Name: "Warm Pad", Folder: "Synth Leads", Path: filepath.Join("D:", "Pads", "Warm.nkm"), Kind: "Multi", Extension: ".nkm", Category: KontaktCategoryLoadable, OpenMode: OpenModeKontakt},
		{Name: "Library Resources", Folder: "Library", Path: filepath.Join("D:", "Library", "Resources.nkr"), Kind: "Recurso", Extension: ".nkr", Category: KontaktCategorySupport, OpenMode: OpenModeReveal},
	}

	for query, expected := range map[string]string{
		"piano":    "Grand Piano",
		"acoustic": "Grand Piano",
		"pads":     "Warm Pad",
		"  WARM  ": "Warm Pad",
		"multi":    "Warm Pad",
		".nkm":     "Warm Pad",
	} {
		filtered := filterInstruments(items, query)
		if len(filtered) != 1 || filtered[0].Name != expected {
			t.Errorf("busca %q: resultado %#v, esperava %q", query, filtered, expected)
		}
	}

	if filtered := filterInstruments(items, "não existe"); len(filtered) != 0 {
		t.Fatalf("busca sem resultado retornou %#v", filtered)
	}

	filtered := filterInstrumentsByType(items, "", ".nkm")
	if len(filtered) != 1 || filtered[0].Name != "Warm Pad" {
		t.Fatalf("filtro por formato retornou %#v", filtered)
	}
	if filtered := filterInstrumentsByType(items, "piano", ".nkm"); len(filtered) != 0 {
		t.Fatalf("combinação de busca e formato retornou %#v", filtered)
	}
	filtered = filterInstrumentsByCategory(items, "", KontaktCategoryLoadable)
	if len(filtered) != 2 {
		t.Fatalf("filtro de carregáveis retornou %#v", filtered)
	}
	filtered = filterInstrumentsByCategory(items, "resources", KontaktCategorySupport)
	if len(filtered) != 1 || filtered[0].Extension != ".nkr" {
		t.Fatalf("combinação de categoria e busca retornou %#v", filtered)
	}
}

func TestKontaktFileClassificationsExcludeGenericAudio(t *testing.T) {
	for _, extension := range []string{".nksn", ".nksf", ".nka", ".nkg", ".nkp", ".nicnt", ".nkr", ".nkx", ".nkc", ".ncw"} {
		if _, supported := kontaktFileSpecForExtension(extension); !supported {
			t.Errorf("%s deveria ser catalogado", extension)
		}
	}
	for _, extension := range []string{".wav", ".aif", ".aiff", ".txt"} {
		if spec, supported := kontaktFileSpecForExtension(extension); supported {
			t.Errorf("%s não deve entrar no catálogo: %#v", extension, spec)
		}
	}
}

func TestOnlyStandaloneKontaktFilesCanOpenDirectly(t *testing.T) {
	for _, extension := range []string{".nki", ".NKM", ".nkb"} {
		if !kontaktFileCanOpenDirectly(extension) {
			t.Errorf("%s deveria ser carregável diretamente", extension)
		}
	}
	for _, extension := range []string{".nksn", ".nksf", ".nka", ".nkg", ".nkp", ".nicnt", ".nkr", ".nkx", ".nkc", ".ncw"} {
		if kontaktFileCanOpenDirectly(extension) {
			t.Errorf("%s depende de contexto e não deve ser aberto diretamente", extension)
		}
	}
}

func TestScanLibraryReportsMissingRoot(t *testing.T) {
	missing := filepath.Join(t.TempDir(), "missing")
	lib := scanLibrary(missing)
	if lib.ScanError == "" {
		t.Fatal("esperava erro para uma biblioteca ausente")
	}
	if lib.Name != "missing" {
		t.Fatalf("nome inesperado: %q", lib.Name)
	}
}
