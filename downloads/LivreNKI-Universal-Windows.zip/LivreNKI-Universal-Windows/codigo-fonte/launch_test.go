package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestValidateKontaktExecutable(t *testing.T) {
	dir := t.TempDir()
	executable := filepath.Join(dir, "Kontakt 8.exe")
	if err := os.WriteFile(executable, []byte("fixture"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := validateKontaktExecutable(executable); err != nil {
		t.Fatalf("executável válido foi rejeitado: %v", err)
	}
	if err := validateKontaktExecutable(filepath.Join(dir, "Kontakt 8.txt")); err == nil {
		t.Fatal("arquivo sem extensão .exe deveria ser rejeitado")
	}
	if err := validateKontaktExecutable(filepath.Join(dir, "Missing.exe")); err == nil {
		t.Fatal("executável ausente deveria ser rejeitado")
	}
	if err := validateKontaktExecutable(dir); err == nil {
		t.Fatal("pasta deveria ser rejeitada")
	}
}

func TestQuoteWindowsArgument(t *testing.T) {
	tests := map[string]string{
		`C:\Kontakt\Piano.nki`:           `C:\Kontakt\Piano.nki`,
		`C:\My Library\Grand Piano.nki`:  `"C:\My Library\Grand Piano.nki"`,
		`C:\Folder With Space\`:          `"C:\Folder With Space\\"`,
		`C:\Library\A "Quoted" File.nki`: `"C:\Library\A \"Quoted\" File.nki"`,
		``:                               `""`,
	}
	for input, expected := range tests {
		if actual := quoteWindowsArgument(input); actual != expected {
			t.Errorf("quoteWindowsArgument(%q) = %q; esperava %q", input, actual, expected)
		}
	}
}

func TestExplorerSelectParametersAlwaysQuotesPath(t *testing.T) {
	for input, expected := range map[string]string{
		`C:\Library\Piano.nki`:         `/select,"C:\Library\Piano.nki"`,
		`C:\Library\Name, Variant.nki`: `/select,"C:\Library\Name, Variant.nki"`,
	} {
		if actual := explorerSelectParameters(input); actual != expected {
			t.Errorf("explorerSelectParameters(%q) = %q; esperava %q", input, actual, expected)
		}
	}
}
