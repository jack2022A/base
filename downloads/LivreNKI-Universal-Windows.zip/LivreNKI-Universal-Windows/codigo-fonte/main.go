//go:build windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"

	"github.com/lxn/walk"
	. "github.com/lxn/walk/declarative"
)

const appTitle = "LivreNKI Universal"

var (
	darkBackground = walk.RGB(24, 26, 30)
	darkPanel      = walk.RGB(31, 34, 39)
	darkInput      = walk.RGB(42, 45, 51)
	lightText      = walk.RGB(239, 241, 244)
	mutedText      = walk.RGB(171, 177, 186)
	accent         = walk.RGB(235, 143, 61)
)

var kontaktTypeFilterLabels = []string{
	"Todos os formatos",
	"Carregáveis",
	"Presets",
	"Componentes",
	"Suporte",
}

func kontaktCategoryForFilter(index int) KontaktCategory {
	switch index {
	case 1:
		return KontaktCategoryLoadable
	case 2:
		return KontaktCategoryPreset
	case 3:
		return KontaktCategoryComponent
	case 4:
		return KontaktCategorySupport
	default:
		return ""
	}
}

type libraryListModel struct {
	walk.ListModelBase
	items []Library
}

func (m *libraryListModel) ItemCount() int { return len(m.items) }

func (m *libraryListModel) Value(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	lib := m.items[index]
	if lib.ScanError != "" {
		return fmt.Sprintf("%s  •  indisponível", lib.Name)
	}
	return fmt.Sprintf("%s  •  %s", lib.Name, instrumentCount(len(lib.Instruments)))
}

func (m *libraryListModel) ID(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	return strings.ToLower(m.items[index].Root)
}

func (m *libraryListModel) setItems(items []Library) {
	m.items = items
	m.PublishItemsReset()
}

type instrumentTableModel struct {
	walk.TableModelBase
	items []Instrument
}

func (m *instrumentTableModel) RowCount() int { return len(m.items) }

func (m *instrumentTableModel) Value(row, column int) interface{} {
	if row < 0 || row >= len(m.items) {
		return ""
	}
	item := m.items[row]
	switch column {
	case 0:
		return item.Name
	case 1:
		return fmt.Sprintf("%s · %s (%s)", item.Category, item.Kind, item.Extension)
	case 2:
		return item.Folder
	case 3:
		if item.ModifiedAt.IsZero() {
			return ""
		}
		return item.ModifiedAt.Format("02/01/2006 15:04")
	default:
		return ""
	}
}

func (m *instrumentTableModel) ID(index int) interface{} {
	if index < 0 || index >= len(m.items) {
		return ""
	}
	return strings.ToLower(m.items[index].Path)
}

func (m *instrumentTableModel) setItems(items []Instrument) {
	m.items = items
	m.PublishRowsReset()
}

type nativeApp struct {
	mw              *walk.MainWindow
	libraryList     *walk.ListBox
	instrumentTable *walk.TableView
	search          *walk.LineEdit
	typeFilter      *walk.ComboBox
	libraryTitle    *walk.Label
	rootLabel       *walk.Label
	statusLabel     *walk.Label
	kontaktLabel    *walk.Label
	removeButton    *walk.PushButton
	refreshButton   *walk.PushButton
	openButton      *walk.PushButton
	resetKontakt    *walk.PushButton

	libraryModel    *libraryListModel
	instrumentModel *instrumentTableModel
	libraries       []Library
	settingsPath    string
	kontaktPath     string
	scanRevision    uint64
}

func main() {
	if err := run(); err != nil {
		walk.MsgBox(nil, appTitle, err.Error(), walk.MsgBoxOK|walk.MsgBoxIconError)
	}
}

func run() error {
	settingsPath, err := defaultSettingsPath()
	if err != nil {
		return err
	}

	settings, loadErr := loadSettings(settingsPath)
	a := &nativeApp{
		libraryModel:    &libraryListModel{},
		instrumentModel: &instrumentTableModel{},
		settingsPath:    settingsPath,
		kontaktPath:     settings.KontaktPath,
	}
	for _, root := range settings.Roots {
		a.libraries = append(a.libraries, Library{Name: libraryName(root), Root: root})
	}
	a.libraryModel.items = a.libraries

	if err := a.createWindow(); err != nil {
		return fmt.Errorf("criar janela: %w", err)
	}
	setDarkTitleBar(uintptr(a.mw.Handle()))
	a.updateKontaktState()

	if loadErr != nil {
		a.setStatus("Não foi possível ler as configurações: " + loadErr.Error())
	} else if len(a.libraries) == 0 {
		a.setStatus("Adicione uma pasta para catalogar arquivos relacionados ao Kontakt.")
	} else {
		a.libraryList.SetCurrentIndex(0)
		a.updateSelectedLibrary()
		a.startScan()
	}

	a.mw.Run()
	return nil
}

func (a *nativeApp) createWindow() error {
	backgroundBrush := SolidColorBrush{Color: darkBackground}
	panelBrush := SolidColorBrush{Color: darkPanel}
	inputBrush := SolidColorBrush{Color: darkInput}

	return (MainWindow{
		AssignTo:   &a.mw,
		Title:      appTitle + " — Bibliotecas Kontakt",
		Size:       Size{Width: 1120, Height: 720},
		MinSize:    Size{Width: 840, Height: 520},
		Background: backgroundBrush,
		Font:       Font{Family: "Segoe UI", PointSize: 10},
		Layout:     VBox{MarginsZero: true, SpacingZero: true},
		Children: []Widget{
			Composite{
				MinSize:    Size{Height: 76},
				MaxSize:    Size{Height: 76},
				Background: panelBrush,
				Layout:     HBox{Margins: Margins{Left: 20, Top: 12, Right: 20, Bottom: 10}, Spacing: 12},
				Children: []Widget{
					Composite{
						StretchFactor: 1,
						Background:    panelBrush,
						Layout:        VBox{MarginsZero: true, Spacing: 1},
						Children: []Widget{
							Label{Text: "LivreNKI Universal", TextColor: accent, Font: Font{Family: "Segoe UI", PointSize: 19, Bold: true}},
							Label{Text: "Arquivos carregáveis, presets, componentes e suporte", TextColor: mutedText},
						},
					},
					Composite{
						MinSize:    Size{Width: 360},
						MaxSize:    Size{Width: 430},
						Background: panelBrush,
						Layout:     VBox{MarginsZero: true, Spacing: 3},
						Children: []Widget{
							Label{AssignTo: &a.kontaktLabel, Text: "Kontakt: associação do Windows", TextColor: mutedText, EllipsisMode: EllipsisPath},
							Composite{
								Background: panelBrush,
								Layout:     HBox{MarginsZero: true, Spacing: 6},
								Children: []Widget{
									PushButton{Text: "Selecionar Kontakt.exe", OnClicked: a.selectKontakt},
									PushButton{AssignTo: &a.resetKontakt, Text: "Usar associação", Enabled: false, OnClicked: a.clearKontakt},
								},
							},
						},
					},
				},
			},
			HSplitter{
				HandleWidth: 5,
				Background:  backgroundBrush,
				Children: []Widget{
					Composite{
						MinSize:       Size{Width: 270},
						MaxSize:       Size{Width: 390},
						StretchFactor: 1,
						Background:    panelBrush,
						Layout:        VBox{Margins: Margins{Left: 14, Top: 15, Right: 14, Bottom: 14}, Spacing: 8},
						Children: []Widget{
							Label{Text: "BIBLIOTECAS", TextColor: mutedText, Font: Font{Family: "Segoe UI", PointSize: 9, Bold: true}},
							Composite{
								Background: panelBrush,
								Layout:     HBox{MarginsZero: true, Spacing: 6},
								Children: []Widget{
									PushButton{Text: "+ Adicionar pasta", StretchFactor: 2, OnClicked: a.addLibrary},
									PushButton{AssignTo: &a.removeButton, Text: "Remover", StretchFactor: 1, Enabled: false, OnClicked: a.removeLibrary},
								},
							},
							ListBox{
								AssignTo:              &a.libraryList,
								Model:                 a.libraryModel,
								OnCurrentIndexChanged: a.updateSelectedLibrary,
							},
							Label{AssignTo: &a.rootLabel, Text: "Nenhuma pasta adicionada", TextColor: mutedText, EllipsisMode: EllipsisPath},
						},
					},
					Composite{
						StretchFactor: 3,
						Background:    backgroundBrush,
						Layout:        VBox{Margins: Margins{Left: 16, Top: 15, Right: 16, Bottom: 12}, Spacing: 9},
						Children: []Widget{
							Label{AssignTo: &a.libraryTitle, Text: "Arquivos Kontakt", TextColor: lightText, Font: Font{Family: "Segoe UI", PointSize: 15, Bold: true}},
							Composite{
								Background: backgroundBrush,
								Layout:     HBox{MarginsZero: true, Spacing: 7},
								Children: []Widget{
									LineEdit{
										AssignTo:      &a.search,
										StretchFactor: 3,
										CueBanner:     "Buscar por nome, pasta ou formato...",
										Background:    inputBrush,
										TextColor:     lightText,
										OnTextChanged: a.applyFilter,
									},
									ComboBox{
										AssignTo:              &a.typeFilter,
										MinSize:               Size{Width: 165},
										Model:                 kontaktTypeFilterLabels,
										CurrentIndex:          0,
										OnCurrentIndexChanged: a.applyFilter,
									},
									PushButton{AssignTo: &a.refreshButton, Text: "Atualizar", OnClicked: a.startScan},
									PushButton{AssignTo: &a.openButton, Text: "Abrir no Kontakt", Enabled: false, OnClicked: a.openSelected},
								},
							},
							TableView{
								AssignTo:            &a.instrumentTable,
								Model:               a.instrumentModel,
								AlternatingRowBG:    true,
								ColumnsSizable:      true,
								LastColumnStretched: false,
								Columns: []TableViewColumn{
									{Title: "Nome", Width: 230},
									{Title: "Categoria e tipo", Width: 250},
									{Title: "Pasta", Width: 260},
									{Title: "Modificado", Width: 130},
								},
								OnItemActivated:       a.openSelected,
								OnCurrentIndexChanged: a.updateOpenButton,
							},
							Label{AssignTo: &a.statusLabel, Text: "Pronto", TextColor: mutedText},
						},
					},
				},
			},
		},
	}).Create()
}

func (a *nativeApp) selectKontakt() {
	dialog := new(walk.FileDialog)
	dialog.Title = "Selecionar o executável do Kontakt"
	dialog.Filter = "Executáveis do Windows (*.exe)|*.exe|Todos os arquivos (*.*)|*.*"
	if a.kontaktPath != "" {
		dialog.FilePath = a.kontaktPath
		dialog.InitialDirPath = filepath.Dir(a.kontaktPath)
	}

	accepted, err := dialog.ShowOpen(a.mw)
	if err != nil {
		a.showError("Não foi possível selecionar o Kontakt", err)
		return
	}
	if !accepted {
		return
	}

	selected := normalizeKontaktPath(dialog.FilePath)
	if err := validateKontaktExecutable(selected); err != nil {
		a.showError("Executável do Kontakt inválido", err)
		return
	}

	previous := a.kontaktPath
	a.kontaktPath = selected
	if err := a.persistSettings(); err != nil {
		a.kontaktPath = previous
		a.updateKontaktState()
		a.showError("Não foi possível salvar o Kontakt selecionado", err)
		return
	}
	a.updateKontaktState()
	a.setStatus("Kontakt configurado: " + selected)
}

func (a *nativeApp) clearKontakt() {
	previous := a.kontaktPath
	a.kontaktPath = ""
	if err := a.persistSettings(); err != nil {
		a.kontaktPath = previous
		a.updateKontaktState()
		a.showError("Não foi possível remover a configuração do Kontakt", err)
		return
	}
	a.updateKontaktState()
	a.setStatus("A abertura voltará a usar a associação de arquivos do Windows.")
}

func (a *nativeApp) updateKontaktState() {
	if a.kontaktLabel == nil || a.resetKontakt == nil {
		return
	}
	if a.kontaktPath == "" {
		a.kontaktLabel.SetText("Kontakt: associação do Windows")
		a.kontaktLabel.SetToolTipText("Selecione o Kontakt.exe ou use as associações de arquivo do Windows.")
		a.resetKontakt.SetEnabled(false)
		return
	}

	a.resetKontakt.SetEnabled(true)
	if err := validateKontaktExecutable(a.kontaktPath); err != nil {
		a.kontaktLabel.SetText("Kontakt indisponível: " + filepath.Base(a.kontaktPath))
		a.kontaktLabel.SetToolTipText(err.Error())
		return
	}
	a.kontaktLabel.SetText("Kontakt: " + a.kontaktPath)
	a.kontaktLabel.SetToolTipText(a.kontaktPath)
}

func (a *nativeApp) addLibrary() {
	dialog := new(walk.FileDialog)
	dialog.Title = "Adicionar pasta de biblioteca Kontakt"
	accepted, err := dialog.ShowBrowseFolder(a.mw)
	if err != nil {
		a.showError("Não foi possível abrir a pasta", err)
		return
	}
	if !accepted || strings.TrimSpace(dialog.FilePath) == "" {
		return
	}

	root := filepath.Clean(dialog.FilePath)
	for index, lib := range a.libraries {
		if strings.EqualFold(lib.Root, root) {
			a.libraryList.SetCurrentIndex(index)
			a.setStatus("Esta biblioteca já está na lista.")
			return
		}
	}

	a.libraries = append(a.libraries, Library{Name: libraryName(root), Root: root})
	a.libraryModel.setItems(a.libraries)
	a.libraryList.SetCurrentIndex(len(a.libraries) - 1)
	a.updateSelectedLibrary()
	if err := a.persistSettings(); err != nil {
		a.showError("A biblioteca foi adicionada, mas não pôde ser salva", err)
	}
	a.startScan()
}

func (a *nativeApp) removeLibrary() {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		return
	}
	removedName := a.libraries[index].Name
	a.libraries = append(a.libraries[:index], a.libraries[index+1:]...)
	a.libraryModel.setItems(a.libraries)
	if len(a.libraries) > 0 {
		if index >= len(a.libraries) {
			index = len(a.libraries) - 1
		}
		a.libraryList.SetCurrentIndex(index)
	} else {
		a.libraryList.SetCurrentIndex(-1)
	}
	a.updateSelectedLibrary()
	if err := a.persistSettings(); err != nil {
		a.showError("Não foi possível salvar a remoção", err)
		return
	}
	a.scanRevision++ // Invalidate a scan that may still be running.
	a.refreshButton.SetEnabled(len(a.libraries) > 0)
	a.setStatus(fmt.Sprintf("%s foi removida da lista. Nenhum arquivo foi apagado.", removedName))
}

func (a *nativeApp) persistSettings() error {
	roots := make([]string, len(a.libraries))
	for index, lib := range a.libraries {
		roots[index] = lib.Root
	}
	return saveSettings(a.settingsPath, Settings{Roots: roots, KontaktPath: a.kontaktPath})
}

func (a *nativeApp) startScan() {
	if len(a.libraries) == 0 {
		a.setStatus("Adicione uma pasta para começar.")
		return
	}

	selectedRoot := a.currentRoot()
	roots := make([]string, len(a.libraries))
	for index, lib := range a.libraries {
		roots[index] = lib.Root
	}
	a.scanRevision++
	revision := a.scanRevision
	a.refreshButton.SetEnabled(false)
	a.setStatus(fmt.Sprintf("Escaneando %d biblioteca(s)...", len(roots)))

	go func() {
		scanned := make([]Library, 0, len(roots))
		for _, root := range roots {
			scanned = append(scanned, scanLibrary(root))
		}
		a.mw.Synchronize(func() {
			if revision != a.scanRevision {
				return
			}
			a.libraries = scanned
			a.libraryModel.setItems(a.libraries)
			index := a.indexOfRoot(selectedRoot)
			if index < 0 && len(a.libraries) > 0 {
				index = 0
			}
			a.libraryList.SetCurrentIndex(index)
			a.refreshButton.SetEnabled(true)
			a.updateSelectedLibrary()

			total, failures := 0, 0
			for _, lib := range a.libraries {
				total += len(lib.Instruments)
				if lib.ScanError != "" {
					failures++
				}
			}
			if failures > 0 {
				a.setStatus(fmt.Sprintf("%s encontrados. %d biblioteca(s) não puderam ser lidas.", instrumentCount(total), failures))
			} else {
				a.setStatus(fmt.Sprintf("%s encontrados em %d biblioteca(s).", instrumentCount(total), len(a.libraries)))
			}
		})
	}()
}

func (a *nativeApp) currentRoot() string {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		return ""
	}
	return a.libraries[index].Root
}

func (a *nativeApp) indexOfRoot(root string) int {
	for index, lib := range a.libraries {
		if strings.EqualFold(lib.Root, root) {
			return index
		}
	}
	return -1
}

func (a *nativeApp) updateSelectedLibrary() {
	index := a.libraryList.CurrentIndex()
	valid := index >= 0 && index < len(a.libraries)
	a.removeButton.SetEnabled(valid)
	if !valid {
		a.libraryTitle.SetText("Arquivos Kontakt")
		a.rootLabel.SetText("Nenhuma pasta adicionada")
		a.instrumentModel.setItems(nil)
		a.openButton.SetEnabled(false)
		return
	}

	lib := a.libraries[index]
	a.libraryTitle.SetText(fmt.Sprintf("%s  ·  %s", lib.Name, instrumentCount(len(lib.Instruments))))
	a.rootLabel.SetText(lib.Root)
	a.rootLabel.SetToolTipText(lib.Root)
	a.applyFilter()
	if lib.ScanError != "" {
		a.setStatus(lib.ScanError)
	}
}

func (a *nativeApp) applyFilter() {
	index := a.libraryList.CurrentIndex()
	if index < 0 || index >= len(a.libraries) {
		a.instrumentModel.setItems(nil)
		if a.openButton != nil {
			a.openButton.SetEnabled(false)
		}
		return
	}
	category := KontaktCategory("")
	if a.typeFilter != nil {
		category = kontaktCategoryForFilter(a.typeFilter.CurrentIndex())
	}
	filtered := filterInstrumentsByCategory(a.libraries[index].Instruments, a.search.Text(), category)
	a.instrumentModel.setItems(filtered)
	a.updateOpenButton()
	query := strings.TrimSpace(a.search.Text())
	if query != "" {
		a.setStatus(fmt.Sprintf("%s correspondem à busca “%s”.", instrumentCount(len(filtered)), query))
	} else if category != "" {
		a.setStatus(fmt.Sprintf("%s no filtro %s.", instrumentCount(len(filtered)), category))
	}
}

func (a *nativeApp) updateOpenButton() {
	if a.openButton == nil || a.instrumentTable == nil {
		return
	}
	index := a.instrumentTable.CurrentIndex()
	valid := index >= 0 && index < len(a.instrumentModel.items)
	a.openButton.SetEnabled(valid)
	if !valid || a.instrumentModel.items[index].OpenMode == OpenModeKontakt {
		a.openButton.SetText("Abrir no Kontakt")
		return
	}
	a.openButton.SetText("Mostrar na pasta")
}

func (a *nativeApp) openSelected() {
	index := a.instrumentTable.CurrentIndex()
	if index < 0 || index >= len(a.instrumentModel.items) {
		return
	}
	item := a.instrumentModel.items[index]
	if item.OpenMode != OpenModeKontakt {
		if err := shellShowInFolder(uintptr(a.mw.Handle()), item.Path); err != nil {
			a.showError("Não foi possível mostrar o arquivo na pasta", err)
			return
		}
		if item.Category == KontaktCategoryPreset {
			a.setStatus(fmt.Sprintf("%s depende do instrumento ou produto correspondente; o arquivo foi mostrado na pasta.", item.Kind))
		} else {
			a.setStatus(fmt.Sprintf("%s foi mostrado na pasta. Esse tipo não é aberto isoladamente no Kontakt.", item.Kind))
		}
		return
	}
	var err error
	openingWith := "aplicativo associado"
	if a.kontaktPath != "" {
		if validationErr := validateKontaktExecutable(a.kontaktPath); validationErr != nil {
			a.updateKontaktState()
			a.showError("Kontakt configurado indisponível", validationErr)
			return
		}
		err = shellOpenWithExecutable(uintptr(a.mw.Handle()), a.kontaktPath, item.Path)
		openingWith = "Kontakt configurado"
	} else {
		err = shellOpen(uintptr(a.mw.Handle()), item.Path)
	}
	if err != nil {
		a.showError("Não foi possível abrir o arquivo", err)
		return
	}
	a.setStatus(fmt.Sprintf("Abrindo “%s” (%s) no %s...", item.Name, item.Extension, openingWith))
}

func (a *nativeApp) setStatus(message string) {
	if a.statusLabel != nil {
		a.statusLabel.SetText(message)
	}
}

func (a *nativeApp) showError(title string, err error) {
	walk.MsgBox(a.mw, title, err.Error(), walk.MsgBoxOK|walk.MsgBoxIconError)
}

func instrumentCount(count int) string {
	if count == 1 {
		return "1 arquivo"
	}
	return fmt.Sprintf("%d arquivos", count)
}

var shellExecuteW = syscall.NewLazyDLL("shell32.dll").NewProc("ShellExecuteW")
var getWindowsDirectoryW = syscall.NewLazyDLL("kernel32.dll").NewProc("GetWindowsDirectoryW")

func shellOpen(hwnd uintptr, path string) error {
	verb, err := syscall.UTF16PtrFromString("open")
	if err != nil {
		return err
	}
	file, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return err
	}
	result, _, callErr := shellExecuteW.Call(
		hwnd,
		uintptr(unsafe.Pointer(verb)),
		uintptr(unsafe.Pointer(file)),
		0,
		0,
		1, // SW_SHOWNORMAL
	)
	if result > 32 {
		return nil
	}
	if result == 31 {
		return fmt.Errorf("nenhum aplicativo está associado a %s; associe essa extensão ao Kontakt no Windows", strings.ToLower(filepath.Ext(path)))
	}
	if result == 2 || result == 3 {
		return fmt.Errorf("o arquivo não existe mais: %s", path)
	}
	if callErr != nil && callErr != syscall.Errno(0) {
		return fmt.Errorf("abrir arquivo: %w", callErr)
	}
	return fmt.Errorf("o Windows não conseguiu abrir o arquivo (código %d)", result)
}

func shellOpenWithExecutable(hwnd uintptr, executable, document string) error {
	verb, err := syscall.UTF16PtrFromString("open")
	if err != nil {
		return err
	}
	file, err := syscall.UTF16PtrFromString(executable)
	if err != nil {
		return err
	}
	parameters, err := syscall.UTF16PtrFromString(quoteWindowsArgument(document))
	if err != nil {
		return err
	}
	workingDirectory, err := syscall.UTF16PtrFromString(filepath.Dir(executable))
	if err != nil {
		return err
	}

	result, _, callErr := shellExecuteW.Call(
		hwnd,
		uintptr(unsafe.Pointer(verb)),
		uintptr(unsafe.Pointer(file)),
		uintptr(unsafe.Pointer(parameters)),
		uintptr(unsafe.Pointer(workingDirectory)),
		1, // SW_SHOWNORMAL
	)
	if result > 32 {
		return nil
	}
	if result == 2 || result == 3 {
		return fmt.Errorf("o Kontakt ou o arquivo selecionado não foi encontrado")
	}
	if result == 5 {
		return fmt.Errorf("o Windows negou acesso ao executável configurado")
	}
	if callErr != nil && callErr != syscall.Errno(0) {
		return fmt.Errorf("iniciar Kontakt: %w", callErr)
	}
	return fmt.Errorf("o Windows não conseguiu iniciar o Kontakt (código %d)", result)
}

func shellShowInFolder(hwnd uintptr, path string) error {
	if _, err := os.Stat(path); err != nil {
		if os.IsNotExist(err) {
			return fmt.Errorf("o arquivo não existe mais: %s", path)
		}
		return fmt.Errorf("verificar arquivo: %w", err)
	}
	verb, err := syscall.UTF16PtrFromString("open")
	if err != nil {
		return err
	}
	explorer, err := syscall.UTF16PtrFromString(windowsExplorerPath())
	if err != nil {
		return err
	}
	parameters, err := syscall.UTF16PtrFromString(explorerSelectParameters(path))
	if err != nil {
		return err
	}
	result, _, callErr := shellExecuteW.Call(
		hwnd,
		uintptr(unsafe.Pointer(verb)),
		uintptr(unsafe.Pointer(explorer)),
		uintptr(unsafe.Pointer(parameters)),
		0,
		1, // SW_SHOWNORMAL
	)
	if result > 32 {
		return nil
	}
	if result == 2 || result == 3 {
		return fmt.Errorf("o arquivo não existe mais: %s", path)
	}
	if callErr != nil && callErr != syscall.Errno(0) {
		return fmt.Errorf("abrir Explorador de Arquivos: %w", callErr)
	}
	return fmt.Errorf("o Windows não conseguiu abrir o Explorador de Arquivos (código %d)", result)
}

func windowsExplorerPath() string {
	var buffer [32768]uint16
	length, _, _ := getWindowsDirectoryW.Call(
		uintptr(unsafe.Pointer(&buffer[0])),
		uintptr(len(buffer)),
	)
	if length > 0 && length < uintptr(len(buffer)) {
		return filepath.Join(syscall.UTF16ToString(buffer[:length]), "explorer.exe")
	}

	// SystemRoot is supplied by Windows and also supports installations that
	// are not on drive C. The literal path is only a last-resort fallback.
	if root := strings.TrimSpace(os.Getenv("SystemRoot")); root != "" {
		return filepath.Join(root, "explorer.exe")
	}
	return `C:\Windows\explorer.exe`
}

func setDarkTitleBar(hwnd uintptr) {
	value := int32(1)
	proc := syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
	// DWMWA_USE_IMMERSIVE_DARK_MODE is 20 on current Windows 10/11 and 19 on
	// some older builds. Unsupported calls simply leave the native title bar.
	for _, attribute := range []uintptr{20, 19} {
		result, _, _ := proc.Call(hwnd, attribute, uintptr(unsafe.Pointer(&value)), unsafe.Sizeof(value))
		if result == 0 {
			return
		}
	}
}
